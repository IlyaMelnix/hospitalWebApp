CREATE TRIGGER `user_BEFORE_DELETE`
BEFORE DELETE ON `user`
FOR EACH ROW
  BEGIN
	DELETE FROM `hospital`.`drug` WHERE `hospital`.`drug`.`user_iduser` = old.iduser;
    DELETE FROM `hospital`.`procedure` WHERE `hospital`.`procedure`.`user_iduser` =  old.iduser;
    DELETE FROM `hospital`.`operation` WHERE `hospital`.`operation`.`user_iduser` = old.iduser;
END